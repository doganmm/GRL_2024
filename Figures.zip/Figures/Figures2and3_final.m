clear all
close all
pr_no=[1:18];
v=0.08; %[in meter/nanoseconds]
x=-4.5:0.05:4.5; %[in meters]
y=[-4.35 -3.65 -3.35 -2.65 -2.35 -1.65 -1.35 -0.65 -0.35 ...
    0.35 0.65 1.35 1.65 2.35 2.65 3.35 3.65 4.35]; %[in meters]

z=(0:0.2:52.2)*-v/2; %[in nanoseconds]
K=[];  K_ind=[];

xyz_gpr=load('surferdata_core_gpr.txt');
K=load('Z_gpr.txt');
[XI,YI]=meshgrid(-4.5:0.25:4.5,-4.5:0.25:4.5);
 x_gpr=K(:,1);       x_gpr(end+1)=0;
 y_gpr=K(:,2);       y_gpr(end+1)=0;
 z_gpr=K(:,3);       z_gpr(end+1)=-1.5;
ind0=find(xyz_gpr(:,4)==0);
    xyz_gpr(ind0,4)=NaN;

ZI_gpr=griddata(xyz_gpr(:,1),xyz_gpr(:,2),xyz_gpr(:,4),XI,YI);

%interpreting the core data
core_data=load('frx6.txt');
xyz_core=load('surferdata_core.txt');
ind0=find(xyz_core(:,3)==0);
xyz_core(ind0,3)=NaN;

core_data(end+1,:)=[0 0 4.92126 4.92126 NaN];
theta=core_data(:,2)*pi/180;
theta=(2*pi)-(theta-(pi/2));
rho=0.3048*core_data(:,1); %ft conversion 0.3048
Z=-0.3048*core_data(:,3);
Zcore=-0.3048*core_data(:,4);

[X,Y] = pol2cart(theta,rho);

[ZII]=griddata(xyz_core(:,1),xyz_core(:,2),xyz_core(:,3),XI,YI);

%----Fig2 start
figure('position',[100 100 600 400])
for i=1:length(y);
    line([y(i) y(i) ],[-4.5 4.5 ],[-2 -2 ],'Color',[160/255 160/255 160/255],'LineStyle','--','LineWidth',0.5)
    line([-4.5 4.5 ],[y(i) y(i) ],[-2 -2 ],'Color',[160/255 160/255 160/255],'LineStyle','--','LineWidth',0.5)
end
hold on,grid on
surf(XI,YI,ZII), axis equal,xlim([-4.5 4.5]),ylim([-4.5 4.5]),zlim([-2 0]),caxis([-1.6 -0.6]),view([-30 20]); shading interp;hold on
for i=1:length(Zcore);
   line([X(i) X(i)],[Y(i) Y(i)],[0 Zcore(i)],'LineStyle','-','LineWidth',1.5,'Color','r')
    plot3(X(i), Y(i),Z(i),'r-')
end
plot3(X,Y,Z,'+','Color',[128/255 128/255 128/255]);
ind=find(isnan(Z));
for i=1:length(ind);
 line([X(ind(i)) X(ind(i))],[Y(ind(i)) Y(ind(i))],[0 Zcore(ind(i))],'Color',[128/255 128/255 128/255],'LineStyle','-','LineWidth',1.5)
end
 line([0 0],[0 0],[0 -1.5],'Color', 'k','LineStyle','-','LineWidth',1.5),plot3(0,0,-1.5,'+');
 rectangle('Position',[-4.5,-4.5,9,9])
 line([-4.5 -4.5 ],[-4.5 -4.5 ],[0 -2 ],'Color','k')
 line([4.5 4.5 ],[-4.5 -4.5 ],[0 -2 ],'Color','k')
  plot3(YI(:,18),XI(:,18),ZI_gpr(:,18),'k','LineWidth',1.5)
    for i=3:4:37;
plot3(XI(i,:),YI(i,:),ZII(i,:),'Color',[128/255 128/255 128/255])
plot3(XI(:,i),YI(:,i),ZII(:,i),'Color',[128/255 128/255 128/255])
    end
    
a=fill3([4.5 -4.5 -4.5 4.5],[-0.35 -0.35 -0.35 -0.35],[0 0 -2 -2],[64/255 64/255 64/255]); alpha(a,0.2); 
set(gca,'FontSize',10)
h=colorbar('Position',[0.74 0.25 0.2 0.02],'Orientation','Horizontal','Color','k','FontSize',8);
h.Label.String = 'Depth [m]','FontSize',8;
 xlabel('Easting [m]','FontSize',10), ylabel('Northing [m]','FontSize',10),zlabel('Depth [m]','FontSize',10),hold off 
  %---Fig2 end  

  % COMPARISON
figure('position',[100 100 600 600])
ax1=axes('Position',[0.07 0.58 0.41 0.41]),hold on
vc = [-0.6,-0.7,-0.8,-0.9,-1,-1.1,-1.2,-1.5,-1.6,-1.7];
% F = scatteredInterpolant(xyz_core(:,1),xyz_core(:,2),xyz_core(:,3)
F = scatteredInterpolant(xyz_gpr(:,1),xyz_gpr(:,2),xyz_gpr(:,4),'nearest','none');
vq = F(XI,YI); 
contourf(XI,YI,vq,vc,'ShowText','on'),caxis([-1.6 -0.6]),axis equal, 

xlim([-4.5,4.5]),ylim([-4.5,4.5]),xlabel('Easting [m]'),hold on
ylabel('Northing [m]');
a=fill3([-4.5 -4.5 4.5 4.5],[-4.5 4.5 4.5 -4.5],[0 0 0 0],'w'); alpha(a,0.25); 

ind=find(isnan(core_data(:,3)));
plot(X,Y,'ok','MarkerFaceColor','r','MarkerSize',5),plot(X(ind),Y(ind),'ok','MarkerFaceColor',[128/255 128/255 128/255],'MarkerSize',5)
plot(X(end),Y(end),'ow','MarkerFaceColor','k','MarkerSize',5)
plot(y_gpr,x_gpr,'k.')
h=colorbar('Position',[0.25 0.64 0.2 0.02],'Orientation','Horizontal','Color','k')
h.Label.String = 'Depth [m]';
text(-4.25, 4,'(a)','Color','k','FontSize',12,'FontWeight','Bold')
box on,grid on,hold off,

ax2=axes('Position',[0.569 0.58 0.41 0.41]),hold on

contourf(XI,YI,ZII,vc,'ShowText','on'),caxis([-1.6 -0.6]),axis equal,xlim([-4.5,4.5]),ylim([-4.5,4.5]),xlabel('Easting [m]'),hold on
ylabel('Northing [m]'),grid on,box on
a=fill3([-4.5 -4.5 4.5 4.5],[-4.5 4.5 4.5 -4.5],[0 0 0 0],'w'); alpha(a,0.25); 

% voronoi(X,Y)
ind=find(isnan(core_data(:,3)));
plot(X,Y,'ok','MarkerFaceColor','r','MarkerSize',5),plot(X(ind),Y(ind),'ok','MarkerFaceColor',[128/255 128/255 128/255],'MarkerSize',5)
plot(X(end),Y(end),'ow','MarkerFaceColor','k','MarkerSize',5)
h=colorbar('Position',[0.745 0.64 0.2 0.02],'Orientation','Horizontal','Color','k');
h.Label.String = 'Depth [m]';
text(-4.25, 4,'(b)','Color','k','FontSize',12,'FontWeight','Bold')
hold off

ax3=axes('Position',[0.07 0.08 0.41 0.41]),hold on
vc_err = [-20, -10, -5, 0, 5, 10, 20];
err=((ZI_gpr-ZII)./ZII).*100;
contourf(XI,YI,err,vc_err,'ShowText','on'),caxis([-15 15]),axis equal,xlim([-4.5,4.5]),ylim([-4.5,4.5]),xlabel('Easting [m]'),hold on
ylabel('Northing [m]'),grid on,box on,
a=fill3([-4.5 -4.5 4.5 4.5],[-4.5 4.5 4.5 -4.5],[0 0 0 0],'w'); alpha(a,0.25); 

ind=find(isnan(core_data(:,3)));
plot(X,Y,'ok','MarkerFaceColor','r','MarkerSize',5),plot(X(ind),Y(ind),'ok','MarkerFaceColor',[128/255 128/255 128/255],'MarkerSize',5)
plot(X(end),Y(end),'ow','MarkerFaceColor','k','MarkerSize',5)
h=colorbar('Position',[0.25 0.14 0.2 0.02],'Orientation','Horizontal','Color','k');
h.Label.String = 'Error [%]';
text(-4.25, 4,'(c)','Color','k','FontSize',12,'FontWeight','Bold')
hold off

ax4=axes('Position',[0.569 0.08 0.41 0.41]),hold on

plot(ZII(:),ZI_gpr(:),'ko','MarkerFaceColor','k','MarkerSize',2),hold on

for i=1:length(X);
    diffx=XI(1,:)-X(i);
    ind_x=find(abs(diffx)==min(abs(diffx)));
    diffy=YI(:,1)-Y(i);
    ind_y=find(abs(diffy)==min(abs(diffy)));
    out(i,1:2)=[XI(1,ind_x) YI(ind_y,1)];
end
out=round((out+4.5)./0.25);
for k=1:length(out);
    i=out(k,1);
    j=out(k,2);
    out_Z(k)=ZI_gpr(i,j);
end
plot(Z,out_Z,'ko','MarkerFaceColor','r','MarkerSize',5),axis equal,xlim([-1.65,-0.6]),ylim([-1.65,-0.6]), line([0 -2],[0 -2],'Color','k'),xlabel('Depth from Cores [m]')
ylabel('Depth from GPR [m]'),box on
text(-1.62, -0.65,'(d)','Color','k','FontSize',12,'FontWeight','Bold')
hold off

%Rsquared calculation
ind=find(~isnan(ZII(:))); ZI=ZII(ind); ZI_gpr=ZI_gpr(ind);
ind=find(~isnan(ZI_gpr)); ZI=ZI(ind); ZI_gpr=ZI_gpr(ind);

mean_y=nanmean(ZI(:));
SS_tot=sum(nansum((ZI_gpr-mean_y).^2));
SS_res=sum(nansum((ZI-ZI_gpr).^2));
Rsqrd=1-(SS_res/SS_tot);