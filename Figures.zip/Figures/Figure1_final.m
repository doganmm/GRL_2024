clear all
close all
pr_no=[1:18];
v=0.08; %[in meter/nanoseconds]
x=-4.5:0.05:4.5; %[in meters]
y=-4.25:0.5:4.5; %[in meters]
z=(0:0.2:52.2)*-v/2; %[in nanoseconds]
K=[];  K_ind=[];

[XI,ZI]=meshgrid(x,z);

for i=9;
    fname1=['CELL6_BEFORE_WTOE_' num2str(i) '.ASC'];
    fname2=['CELL6_AFTER_WTOE_' num2str(i) '.ASC'];
    before=load(fname1);  before=before./max(before(:));
    after=load(fname2);     after=after./max(after(:));

figure('position',[100 100 600 400])
ax1=axes('Position',[0.05 0.7 0.95 0.25]),hold on
pcolor(XI,ZI,before),caxis([-1 1]),shading interp,axis equal, xlim([-4.5 4.5]), ylim([-2 0]),box on
colormap(ax1,jet(21)),ylabel('Depth [m]'),set(gca,'XTicklabel','','TickDir' ,'out')
text(-1.25, 0.2,'Borehole','Color','k'),annotation('textarrow','Position',[0.525 0.99 0.0001 -0.03])
rectangle('Position',[-0.05,-1.5,0.1,1.5],'EdgeColor','k'),
text(-4.5, -0.2,'(a)','Color','k','FontSize',12,'FontWeight','Bold'),hold off

ax2=axes('Position',[0.05 0.42 0.95 0.25]),hold on
pcolor(XI,ZI,after),caxis([-1  1]),shading interp,axis equal, xlim([-4.5 4.5]), ylim([-2 0]),box on
colormap(ax2,jet(21)),colorbar('Position',[0.925 0.42 0.02 0.2],'Orientation','Vertical','Color','k')
rectangle('Position',[-0.05,-1.5,0.1,1.5],'EdgeColor','k'),
text(4.25, -2.25,'Norm. Amp.','Color','k'),text(-4.5, -0.2,'(b)','Color','k','FontSize',12,'FontWeight','Bold')
ylabel('Depth [m]'),set(gca,'XTicklabel','','TickDir' ,'out')
hold off
      
    hil_before=abs(hilbert(before));
    hil_after=abs(hilbert(after));
    hil_diff=hil_after-hil_before;
    ind=find(hil_diff<=0);
    hil_diff_pos=hil_diff;
    hil_diff_pos(ind)=0;
    
for j=1:181;
    ind=find(hil_diff_pos(:,j)==max(hil_diff_pos(:,j)));
    if ind>10 & 210>ind;
        K_ind=[K_ind; i j ind];
        K=[K ; x(j) y(i) z(ind)];
    end  
end
ax3=axes('Position',[0.05 0.12 0.95 0.25]),hold on
pcolor(XI,ZI,hil_diff_pos),caxis([0 1]),shading interp,axis equal, xlim([-4.5 4.5]), ylim([-2 0])
text(4.25, -2.25,'Norm. Amp.','Color','k')
set(gca,'TickDir' ,'out'),rectangle('Position',[-0.05,-1.5,0.1,1.5],'EdgeColor','w'),
colorbar('Position',[0.925 0.12 0.02 0.2],'Orientation','Vertical','Color','k'),box on
colormap(ax3,parula(11)),ylabel('Depth [m]'),xlabel('Easting [m]')
% line([0 0],[0 -1.5],'LineStyle','--','Color','w'),
text(-4.5, -0.2,'(c)','Color','w','FontSize',12,'FontWeight','Bold'),hold off

end

K_backup=K;