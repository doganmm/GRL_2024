function [pickX,pickY,pickZ,pickAMP,x,y,z]=pick(data,XI,YI,ZI,pr)

[R C L] = size(data);
cut = [0 550];

pickX  = ones(R,C,L).*NaN; 
pickY  = ones(R,C,L).*NaN;
pickZ  = ones(R,C,L).*NaN;
pickAMP= ones(R,C,L).*NaN;
for k=1:L;
for j=1:C;
    for i=2:R-1
        back=data(i-1,j,k);
        middle=data(i,j,k);
        front=data(i+1,j,k);
            if middle>=back && middle>=front && middle>0;
               pickX(i,j,k)=XI(i,j,1); 
               pickY(i,j,k)=YI(i,j,1);
               pickZ(i,j,k)=pr(k);
               pickAMP(i,j,k)=middle; 
            end
    end
end
end

pickX(1:cut(1),:,:)  = []; pickX(cut(2):end,:,:)  = [];
pickY(1:cut(1),:,:)  = []; pickY(cut(2):end,:,:)  = [];
pickZ(1:cut(1),:,:)  = []; pickZ(cut(2):end,:,:)  = [];
pickAMP(1:cut(1),:,:)= []; pickAMP(cut(2):end,:,:)= [];
XI(1:cut(1),:,:)     = []; XI(cut(2):end,:,:)= [];
YI(1:cut(1),:,:)     = []; YI(cut(2):end,:,:)= [];
ZI(1:cut(1),:,:)     = []; ZI(cut(2):end,:,:)= [];
%scatter3(pickX(:),pickZ(:),pickY(:),'*'),axis equal
%set(gca,'ZDir','reverse')
%view(5,-8)


save('pickX.mat','pickX')
save('pickY.mat','pickY')
save('pickZ.mat','pickZ')
save('pickAMP.mat','pickAMP')

x = pickX(~isnan(pickX));
y = pickY(~isnan(pickY));
z = pickZ(~isnan(pickZ));

scatter3(x,z,y,'*')%,axis equal, axis tight
set(gca,'ZDir','reverse')

