clear all
%load 2D profile data
data=load('CELL6_3D_WTOE_AFTER.asc');
data=reshape(data,262,181,18);
v=0.08; %velocity m/ns 
%check the size
[r c l]=size(data);
%create the grid
GPRy=0:0.2:(r-1)*0.2;
GPRy=GPRy.*(v/2);
GPRx=0:0.05:0+0.05*(c-1); 
pr=8.75:-0.5:0.25; 
[XI,YI,ZI]=meshgrid(GPRx,GPRy,pr);

[pickX,pickY,pickZ,pickAMP,x,y,z]=pick(data,XI,YI,ZI,pr);

